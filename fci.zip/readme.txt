
FIRST Download

1.XAMPP

5. Extract the file and copy "E_Learning" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name dblms

6. Import dblms.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/E_Learning


**LOGIN DETAILS** 

for user create or student

Admin
user: admin@example.com
pass: admin
